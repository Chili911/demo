#include <stdio.h>

int main(){
	/*
	//declare an array of size 5 that holds integers
	int numbers[5];
	int temp = 25;
	float x = 3.14;
	char y = 97;
	printf("character is %c\n", y);
	printf("address of y is : %p\n", &y);
	
	scanf("%d", &numbers[0]);
	scanf("%d", &numbers[1]);
	scanf("%d", &numbers[2]);
	scanf("%d", &numbers[3]);
	scanf("%d", &numbers[4]);
	
	if(numbers[0] > numbers[1])
	{	
		temp = numbers[0];
		numbers[0] = numbers[1];
		numbers[1] = temp;
	}
	//numbers[1] is >= numbers[0] (always true)
	
	if(numbers[1] > numbers[2])
	{	
		temp = numbers[1];
		numbers[1] = numbers[2];
		numbers[2] = temp;
	}
	
	if(numbers[2] > numbers[3])
	{	
		temp = numbers[2];
		numbers[2] = numbers[3];
		numbers[3] = temp;
	}
	
	if(numbers[3] > numbers[4])
	{	
		temp = numbers[3];
		numbers[3] = numbers[4];
		numbers[4] = temp;
	}
	//done with the first round
	
	//start the second round
	if(numbers[0] > numbers[1])
	{	
		temp = numbers[0];
		numbers[0] = numbers[1];
		numbers[1] = temp;
	}
	//numbers[1] is >= numbers[0] (always true)
	
	if(numbers[1] > numbers[2])
	{	
		temp = numbers[1];
		numbers[1] = numbers[2];
		numbers[2] = temp;
	}
	
	if(numbers[2] > numbers[3])
	{	
		temp = numbers[2];
		numbers[2] = numbers[3];
		numbers[3] = temp;
	}
	//done with the second round
	
	//start third round
	if(numbers[0] > numbers[1])
	{	
		temp = numbers[0];
		numbers[0] = numbers[1];
		numbers[1] = temp;
	}
	//numbers[1] is >= numbers[0] (always true)
	
	if(numbers[1] > numbers[2])
	{	
		temp = numbers[1];
		numbers[1] = numbers[2];
		numbers[2] = temp;
	}
	//end of round 3
	//start of round 4
	if(numbers[0] > numbers[1])
	{	
		temp = numbers[0];
		numbers[0] = numbers[1];
		numbers[1] = temp;
	}
	
	printf("numbers[0] = %d\n", numbers[0]);
	printf("numbers[1] = %d\n", numbers[1]);
	printf("numbers[2] = %d\n", numbers[2]);
	printf("numbers[3] = %d\n", numbers[3]);
	printf("numbers[4] = %d\n", numbers[4]);
	*/
	
	int i;
	i = 0;
	while(i < 5){
		printf("Ahmad BinSalman\n");
		i = i + 1;
	}
	
	
	
	return 0;
}







