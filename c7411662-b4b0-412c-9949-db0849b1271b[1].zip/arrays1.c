#include <stdio.h>

/*
	int numbers [5];
	numbers[0] = 3;
	numbers[1] = 4;
	numbers[2] = 5;
	numbers[3] = 1;
	numbers[4] = 2;	
	*/

int main(){
	int numbers [] = {3,14,5,1,2};//short cut notation
	
	int loc;
	int lnsf;
	lnsf = numbers[0]; //assume that first number
			//is the largest number
	loc = 1; //0 is used for the largest number assumption
	
	if(lnsf < numbers[1])
		lnsf = numbers[1];	
	//loc = loc + 1;
	
	if(lnsf < numbers[2])
		lnsf = numbers[2];
	//loc = loc + 1;
	
	if(lnsf < numbers[3])
		lnsf = numbers[3];
	//loc = loc + 1;
	
	if(lnsf < numbers[4])
		lnsf = numbers[4];


	printf("The lnsf is %d\n", lnsf);




	return 0;
}
